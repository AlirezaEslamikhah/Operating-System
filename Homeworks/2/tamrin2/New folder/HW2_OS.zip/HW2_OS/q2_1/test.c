#include <stdio.h>


int main()
{
    for(int i = 0; i < 10; i++)
    {
        system("google-chrome localhost:8090");
    }
    return 0;
}